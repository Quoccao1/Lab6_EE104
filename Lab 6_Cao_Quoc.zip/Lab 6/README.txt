Quoc Cao
EE104
Lab#6

Reference: Laboratory Assignment 6

***Github link:https://github.com/Quoccao1/Lab6_EE104.git
***Video link for the Hapy garden game: https://youtu.be/9tdV-J8xw64
***Video link for the OpenAI: https://youtu.be/ml3fgGbPaxM
***Video link for the demonstration: https://youtu.be/Y_Zf40z23gs

***MAKE SURE THAT THE FOLLOWING PYTHON MODULES ARE INSTALLED***
import tensorflow as tf
import matplotlib.pyplot as plt
import pathlib
import certifi
from tensorflow.keras.preprocessing.image import load_img
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from flask import Flask, request
from flask_cors import CORS  #remember to pip install flask_cors
from twilio.twiml.messaging_response import MessagingResponse
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras  import datasets, layers, models
import matplotlib.pyplot as plt
import os
import openai #remember to pip install pandas openai
from dotenv import load_dotenv  #remember to pip install python-dotenv

**CNN Baseline and Test images
-Use the CNNbaseline code in the lab manual that yields 70% accuracy and modified it to achieve 90% or higher accuracy
-Then, run the code
-When it done we will get a model and put it in the test images
-Run the Test images code to see the result

**Open AI
-Follow the instruction from the file openai-quickstart.txt downloaded from Canvas
-Change the picture of the website from a dog to something else
-Change the title from “Name my pet” to something else more generic applicable to things and humans as well
-Change the code to generate 4 names instead of 3 names

**Chat GPT
-Run the given ChatGTP code
-Make one change at a time to the followings 6 criteria and document any output differences after each change 
	  engine=model_engine,
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
-Run the code to see the result


**Happy garden game
-Add hacks and tweaks:More fangflowers, more enemies, rain in the garden 
-Adjust the speed, time of the flower or the enemies appear....etc 
-Run and enjoy the game
